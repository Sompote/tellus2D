Tellus 0.1.4 for Linux (64-bit, x86-64)

Run ./tellus from this folder. Keep tigrim in the same folder: it is the TigrimOS agent
engine of the assistant. The programs need glibc 2.31 or later (Ubuntu 20.04, Debian 11,
Fedora 32 and later) and a desktop with OpenGL.

On a minimal system install the usual desktop libraries first, on Ubuntu or Debian:
    sudo apt install libgl1 libegl1 libxkbcommon-x11-0 libxcursor1 libxi6 libxrandr2 ca-certificates

To put Tellus in the applications menu, copy this folder to /opt/tellus and
tellus.desktop to ~/.local/share/applications/.

Without a licence key Tellus runs as the free academic edition, for teaching and learning
(up to 1,000 elements, 2 phases after the initial phase, the basic soil models). A licence
key lifts the limits: the first start asks for it, and activation needs the internet once.
Ask for a key at tellusfem@gmail.com.

From a terminal:
    ./tellus --activate TLS-XXXX-XXXX-XXXX-XXXX-XXXX     use a seat on this computer
    ./tellus --licence                                    the licence state
    ./tellus --deactivate                                 free the seat
    ./tellus --mcp                                        headless MCP server

Activation checks the key server's certificate against the system certificates
(ca-certificates). Behind a firewall that inspects HTTPS, activation fails with
"invalid peer certificate" until the key server is exempted from inspection.
